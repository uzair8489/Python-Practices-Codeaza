def square(number):
    return number ** 2

def cube(number):
    return number ** 3

def add_numbers(a, b):
    return a + b

def subtract_numbers(a, b):
    return a - b
#                                           Importing Module from A Folder

from folder_module import module2


print("Square: ", module2.square(5))
print("Cube: ", module2.cube(3))
print("Addition: ", module2.add_numbers(10,3))



"""
In The Above Example, i have made a custome module naming 'module2.py' in a separate folder having a name 'folder_module' In the 
module, i have made 4 functions with the functionality of square, cube, addition and substraction. The user can import the module
in any file he wants and then easily can access the functions and by putting the values, its functionalty can be checked. 

"""


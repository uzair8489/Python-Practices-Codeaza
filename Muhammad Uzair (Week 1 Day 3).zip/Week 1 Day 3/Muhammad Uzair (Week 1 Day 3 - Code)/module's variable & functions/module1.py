name = "Uzair"
age = 25

def greet():
    print("Hello " + name + "!")



#                                                 Variables in Module

import module1

print(module1.name)
print(module1.age)   

module1.greet()

print()

"""
In this main file i imported a custome module that i made naming 'module1' and then accessed its variables and also called the
function inside the module. Once i have imported any module, i can access its variables easily and i can also use the
functions or whatever is inside the module.

"""

#                                               